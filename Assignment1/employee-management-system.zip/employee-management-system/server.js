const express = require('express');
const { ApolloServer } = require('apollo-server-express');
const connectDB = require('./config/db');
const userSchema = require('./schemas/userSchema');
const employeeSchema = require('./schemas/employeeSchema');
const userResolvers = require('./resolvers/userResolvers');
const employeeResolvers = require('./resolvers/employeeResolvers');

const app = express();
connectDB();

// Serve static files
app.use('/assets', express.static('assets'));

const server = new ApolloServer({
    typeDefs: [userSchema, employeeSchema],
    resolvers: [userResolvers, employeeResolvers],
    context: ({ req }) => ({ req })
});

async function startServer() {
    await server.start();
    server.applyMiddleware({ app });
    app.listen(process.env.PORT || 4000, () =>
        console.log(`🚀 Server ready at http://localhost:4000${server.graphqlPath}`)
    );
}

startServer();
