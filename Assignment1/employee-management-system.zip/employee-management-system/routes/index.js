const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Employee = require('../models/Employee');

router.get('/health', (req, res) => {
    res.json({ status: 'Server is running' });
});

module.exports = router;
