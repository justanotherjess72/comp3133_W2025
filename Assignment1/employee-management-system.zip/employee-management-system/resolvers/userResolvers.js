const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const userResolvers = {
    
    Query: {
        login: async (_, { username, email, password }) => {

            const user = await User.findOne({ $or: [{ username }, { email }] });

            if (!user || !(await bcrypt.compare(password, user.password))) {

                throw new Error("Invalid credentials");

            }

            const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1d' });

            return { token, user };

        }
    },
    Mutation: {

        signup: async (_, { username, email, password }) => {

            const user = new User({ username, email, password });

            await user.save();

            const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1d' });

            return { token, user };

        }
    }
};

module.exports = userResolvers;
