const Employee = require('../models/Employee');

const employeeResolvers = {

    Query: {

        getAllEmployees: async () => await Employee.find(),
        searchEmployeeById: async (_, { id }) => await Employee.findById(id),
        searchEmployeeByDesignationOrDepartment: async (_, { designation, department }) => {

            return await Employee.find({ $or: [{ designation }, { department }] });

        }
    },

    Mutation: {

        addNewEmployee: async (_, args) => {
            const employee = new Employee(args);
            return await employee.save();
        },

        updateEmployeeById: async (_, { id, ...updates }) => {
            return await Employee.findByIdAndUpdate(id, updates, { new: true });
        },

        deleteEmployeeById: async (_, { id }) => {
            await Employee.findByIdAndDelete(id);
            return "Employee deleted";
        }
        
    }
};

module.exports = employeeResolvers;
